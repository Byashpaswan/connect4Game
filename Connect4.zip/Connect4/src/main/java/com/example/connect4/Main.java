package com.example.connect4;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class Main extends Application {
    private Controller controller;
    @Override
    public void start(Stage primarystage) throws Exception {
        FXMLLoader loader=new FXMLLoader(getClass().getResource("hello-view.fxml"));
        GridPane rootGridpane=loader.load();
        controller=loader.getController();
        controller.createPlayground();
       MenuBar menuBar= createMenu();
       menuBar.prefWidthProperty().bind(primarystage.widthProperty());
        Scene scene=new Scene(rootGridpane);
       Pane menupane= (Pane) rootGridpane.getChildren().get(0);

       menupane.getChildren().add(menuBar);

        primarystage.setScene(scene);
        primarystage.setTitle("Connect Four Game");
        primarystage.setResizable(false);
        primarystage.show();

    }
    private  MenuBar createMenu()
    {   // File Menu
        Menu fileMenu=new Menu("File");
        MenuItem newGame=new MenuItem("New game");
        // Lamda Expression
        newGame.setOnAction(event ->controller.resetGame());
        MenuItem reset=new MenuItem("Reset game");

        reset.setOnAction(actionEvent -> controller.resetGame());
        SeparatorMenuItem separatorMenuItem=new SeparatorMenuItem();
        MenuItem exitGame=new MenuItem("Exit game");

        exitGame.setOnAction(actionEvent -> exitGame());

        fileMenu.getItems().addAll(newGame,reset, separatorMenuItem,exitGame);
        // Help Menu
        Menu helpMenu=new Menu("Help");
        MenuItem aboutGame=new MenuItem("about Connect4");

        aboutGame.setOnAction(event->aboutGame());
        SeparatorMenuItem separator=new SeparatorMenuItem();
        MenuItem aboutMe=new MenuItem("about Me");

        aboutMe.setOnAction(event->aboutMe());
        helpMenu.getItems().addAll(aboutGame,separator,aboutMe);

        MenuBar menuBar=new MenuBar();

        menuBar.getMenus().addAll(fileMenu,helpMenu);
        return menuBar;
    }

    private void aboutMe() {
        Alert alert=new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("About the Developer ");
        alert.setHeaderText("Sriyank sidharth");
        alert.setContentText("I love to play around with code and create games . connect4 is one of them .In free time " +
                " I like to spend time with nears and dears ");
        alert.show();
    }

    private void aboutGame() {
        Alert alert=new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("About Connect Four");
        alert.setHeaderText("How to Play");
        alert.setContentText("Connect4  is a two - Player connection game in which the "+
                "Player first choose a color and then take turn droping colored Disc "+
                " from the top into the seven-Column,six row vertically suspended grid. " +
                "The piece fall straight down , occuping the the next Available space within the column "+
                "The objective of the game is to be the first to form a Horizontal, vertical," +
                "or Digonal line of gour ");
        alert.show();
    }

    private void exitGame() {
        Platform.exit();
        System.exit(0);
    }

    private void resetGame() {
        ////
    }

    public static void main(String[] args)
    {
        launch(args);
    }
}
