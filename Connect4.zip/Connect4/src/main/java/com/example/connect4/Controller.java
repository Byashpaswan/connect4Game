package com.example.connect4;

import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Point2D;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.effect.Light;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.util.Duration;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Controller implements Initializable {
    private static final int Columns=7;
    private static final int Rows=6;
    private static final int Circle_Diameter=80;
    private static final String discColor1="#24303E";
    private static final String discColor2="#4CAA88";

    private static String Player_one="Player one";
    private  static String Player_Two="Player Two";

    private boolean isPlayerOneTurn=true;
    private Disc[][] insertedDiscsArray=new Disc[Rows][Columns];  // for structural changes for :developer
    @FXML
    public GridPane rootGridPane;
    @FXML
    public Pane insertedDiscsPane;
    @FXML
    public Label PlayerNameLabel;
    private boolean isAllowedToInsert=true;// flag to avoid same color disc being added
    public void createPlayground() {


       Shape rectangleWithHoles=createGameStructuralGrid();
        rootGridPane.add(rectangleWithHoles, 0, 1);
        List<Rectangle> rectangleList=createClickableColumns();
        for(Rectangle rectangle:rectangleList) {
            rootGridPane.add(rectangle, 0, 1);
        }
    }
   private Shape createGameStructuralGrid()
   {Shape rectangleWithHoles = new Rectangle((Columns+1) * Circle_Diameter, (Rows+1) * Circle_Diameter);
       for(int row=0;row<Rows;row++)
       {
           for(int col=0;col<Columns;col++)
           {   Circle circle = new Circle();
               circle.setRadius(Circle_Diameter / 2);
               circle.setCenterX(Circle_Diameter / 2);
               circle.setCenterY(Circle_Diameter / 2);
               circle.setSmooth(true);
               circle.setTranslateX(col* (Circle_Diameter + 5)+Circle_Diameter/4);
               circle.setTranslateY(row* (Circle_Diameter + 5)+Circle_Diameter/4);
               rectangleWithHoles=Shape.subtract(rectangleWithHoles,circle);
           }
       }
       rectangleWithHoles.setFill(Color.WHITE);
       return rectangleWithHoles;
   }
   private List<Rectangle> createClickableColumns()
   {
        List<Rectangle> rectangleList=new ArrayList<>();

       for(int col=0;col<Columns;col++) {
           Rectangle rectangle = new Rectangle(Circle_Diameter, (Rows + 1) * Circle_Diameter);
           rectangle.setFill(Color.TRANSPARENT);
           rectangle.setTranslateX(col*(Circle_Diameter+5)+Circle_Diameter / 4);

           rectangle.setOnMouseEntered(event->rectangle.setFill(Color.valueOf("#eeeeee26")));
           rectangle.setOnMouseExited(event->rectangle.setFill(Color.TRANSPARENT));
           final int column=col;
           rectangle.setOnMouseClicked(event->{
               if(isAllowedToInsert) {
                   isAllowedToInsert=false; // when disc is being dropped then no more disc will be inserted
                   insertDisc(new Disc(isPlayerOneTurn), column);
               }
           });
           rectangleList.add(rectangle);
       }
       return rectangleList;
   }

   private void insertDisc(Disc disc,int column)
   {   int row=Rows-1;
       while(row>=0)
       {
           if(getDiscIfPresent(row,column)==null)
               break;
           row--;
       }
       if(row<0)     // if it is full,we cannot anyone disc
           return;
       insertedDiscsArray[row][column]=disc;// for Structural changes :for developers
       insertedDiscsPane.getChildren().add(disc);
       disc.setTranslateX(column* (Circle_Diameter + 5)+Circle_Diameter/4);
       int currentRow=row;
       TranslateTransition translateTransition=new TranslateTransition(Duration.seconds(0.5),disc);
       translateTransition.setToY(row * (Circle_Diameter + 5)+Circle_Diameter/4);
       translateTransition.setOnFinished(event->{
           isAllowedToInsert=true; // Finally when disc is dropped allow next player to insert disc;
           if(gameEnded(currentRow,column))
           {
               gameOver();
               return;
           }
           isPlayerOneTurn=!isPlayerOneTurn;
           PlayerNameLabel.setText(isPlayerOneTurn ? Player_one:Player_Two);
       });
       translateTransition.play();

   }
   private boolean gameEnded(int row,int column)
   {    // Vertical Points: A small Example:Player has inserted his last disc at row=2,colum=3
       //index of each element present in column[rwo][column]:
       List<Point2D> verticalPoints= IntStream.rangeClosed(row-3,row+3)   //range of row values=0,1,2,3,4,5
                                              .mapToObj(r->new Point2D(r,column)) //0,3 1,3 2,3 ,3,3 4,3  5,3 ->point
                                                .collect(Collectors.toList());
       Point2D startPoint1=new Point2D(row-3,column+3);
       List<Point2D> diagonal1Point=IntStream.rangeClosed(0,6)
               .mapToObj(i->startPoint1.add(i,-i)).collect(Collectors.toList());

       Point2D startPoint2=new Point2D(row-3,column-3);
       List<Point2D> diagonal2Point=IntStream.rangeClosed(0,6)
               .mapToObj(i->startPoint2.add(i, i)).collect(Collectors.toList());


       List<Point2D> horizontalPoints= IntStream.rangeClosed(column-3,column+3)
                                              .mapToObj(col->new Point2D(row,col))
                                                     .collect(Collectors.toList());

       boolean isEnded=checkCombination(verticalPoints) ||checkCombination(horizontalPoints)
                           || checkCombination(diagonal1Point)||checkCombination(diagonal2Point);
       return isEnded;
   }

    private boolean checkCombination(List<Point2D> points)
    {   int chain=0;
        for(Point2D point:points)
        {
            int rowIndexForArray= (int) point.getX();
            int columnIndexForArray= (int) point.getY();
            Disc disc=getDiscIfPresent(rowIndexForArray,columnIndexForArray);
            if(disc!=null && disc.isPlayerOneMove==isPlayerOneTurn) { // if the last inserted Disc belongs to the current player
                chain++;
                if (chain == 4) {
                    return true;
                    }
            }
            else{
                    chain=0;
                }



        }
        return false;
    }

    private Disc getDiscIfPresent(int row,int column)
    { // To prevent ArrayIndexOutBoundExecution
        if(row>=Rows || row<0 || column>=Columns || column<0) //if  row or column index in invalid
            return null;
        return insertedDiscsArray[row][column];
    }

    private void gameOver()
   {
       String winner=isPlayerOneTurn ? Player_one:Player_Two;
       System.out.println("winner is " + winner);
       Alert alert=new Alert(Alert.AlertType.INFORMATION);
       alert.setTitle("Connect Four");
       alert.setHeaderText("The Winner is "+ winner);
       alert.setContentText("want to play again ? ");
       ButtonType yesBtn=new ButtonType("Yes");
       ButtonType noBtn=new ButtonType("No Exit");
       alert.getButtonTypes().setAll(yesBtn,noBtn);
       Platform.runLater(()->{
           Optional<ButtonType>  btnClick=alert.showAndWait();
           if(btnClick.isPresent() && btnClick.get()==yesBtn)
           {
               // user chose Yes so Reset the game
               resetGame();
           }
           else
           {
               //user chose No so Exit the game
               Platform.exit();
               System.exit(0);
           }
       });

   }

    public void resetGame() {

        insertedDiscsPane.getChildren().clear(); // remove all inserted disc from pane
        for(int row=0;row<insertedDiscsArray.length;row++)
        {
            for(int col=0;col<insertedDiscsArray[row].length; col++)
              insertedDiscsArray[row][col]=null;
        }
        isPlayerOneTurn=true; // let player start the game
        PlayerNameLabel.setText(Player_one);

        createPlayground(); // prepare a fresh playground
    }

    private static class Disc extends Circle{
        private final boolean isPlayerOneMove;
        public Disc(boolean isPlayerOneMove)
        {
            this.isPlayerOneMove=isPlayerOneMove;
            setRadius(Circle_Diameter/2);
            setFill(isPlayerOneMove? Color.valueOf(discColor1):Color.valueOf(discColor2));
            setCenterX(Circle_Diameter/2);
            setCenterY(Circle_Diameter/2);
        }
   }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}